# Class-Project 1 ReadMe

## Explanation of files included
Project1.R is the working file with all the code used. Proj1.Rmd contains the R Markdown code and documentation used to make Project1_documentation. Project1_documentation is a pdf of all the code and the results obtained, as well as explanation of teh functions used in Question 4.

## Assumptions made:
We utilized the nodeid 0 network for this project. Specifically using 0.edges to build the graph. This may be changed very easily by switching the file sourced in line 8 of Project1.R